---------------------------------------------------------------------------------------------------------------
To run the project, import the project into Eclipse, and run QueryHandler as the main class.

After the console shows "classifiers built", open index.html in web folder as the front end.

In the webpage, you can fill your information into the form and submit it, results will show below the form.

Thank you.
---------------------------------------------------------------------------------------------------------------